
import 'package:flutter/material.dart';

void main() => runApp(KingWCApp());

class KingWCApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'King WC',
      theme: ThemeData(
        primaryColor: Color(0xFF43A047),
        accentColor: Color(0xFFF57C00),
      ),
      home: Scaffold(
        appBar: AppBar(title: Text('King WC')),
        body: Center(child: Text('Welcome to King WC')),
      ),
    );
  }
}
